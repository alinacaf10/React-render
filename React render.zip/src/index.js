import React from "react";
import ReactDOM from "react-dom";

const dlanguage=prompt();
const element=<p>{dlanguage} is awsome</p>
const root=document.querySelector("#root")

ReactDOM.render(element,root)